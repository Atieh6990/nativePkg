import { NotchDevice } from './privateTypes';
declare const devicesWithDynamicIsland: NotchDevice[];
export default devicesWithDynamicIsland;
