import { DeviceInfoNativeModule } from './privateTypes';
declare const _default: DeviceInfoNativeModule;
export default _default;
