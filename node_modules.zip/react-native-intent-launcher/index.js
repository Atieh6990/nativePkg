import { NativeModules } from 'react-native'
import React from 'react'
import IntentConstant from './IntentConstant'
export default NativeModules.IntentLauncher
export {
	IntentConstant
}
